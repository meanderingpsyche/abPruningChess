from view.game_view import GameViewCLI

def main():
    GameViewCLI().start_game_2_experimental_()


if __name__ == '__main__':
    main()
